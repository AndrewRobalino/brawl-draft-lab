import React, { useMemo, useState } from "react";
import { MAPS } from "../data/maps";
import { BRAWLERS } from "../data/brawlers";
import { getRecommendations } from "../logic/recommendationEngine";

const MODES = ["Gem Grab", "Brawl Ball", "Bounty", "Heist", "Hot Zone", "Knockout"];

function groupMapsByMode() {
  const byMode = {};
  for (const mode of MODES) byMode[mode] = [];
  for (const m of MAPS) {
    if (!byMode[m.mode]) byMode[m.mode] = [];
    byMode[m.mode].push(m);
  }
  return byMode;
}

const MAPS_BY_MODE = groupMapsByMode();

function getInitialState() {
  return {
    mode: "Gem Grab",
    mapId: MAPS_BY_MODE["Gem Grab"][0]?.id || null,
    firstPick: true,
    bans: [],
    ourPicks: [],
    enemyPicks: [],
    phase: "bans", // "bans" | "picks" | "done"
    search: "",
    pendingPick: null,
    error: null,
  };
}

const TOTAL_BANS = 6;

export function DraftSimulator({ advanced }) {
  const [state, setState] = useState(getInitialState);

  const currentMap = useMemo(
    () => MAPS.find((m) => m.id === state.mapId) || null,
    [state.mapId]
  );

  const takenSet = useMemo(() => {
    return new Set([
      ...state.bans,
      ...state.ourPicks,
      ...state.enemyPicks,
    ]);
  }, [state.bans, state.ourPicks, state.enemyPicks]);

  const enemyIsFirst =
    state.phase !== "bans" && state.firstPick === false;

  const currentPickInfo = useMemo(() => {
    if (state.phase === "bans") {
      const banNumber = state.bans.length + 1;
      const side = banNumber % 2 === 1 ? "Your ban" : "Enemy ban";
      return {
        label: `Ban ${banNumber} / ${TOTAL_BANS}`,
        side,
      };
    }

    // Pick phase
    const our = state.ourPicks.length;
    const enemy = state.enemyPicks.length;

    // pick order: first pick: A1, B2, B3, A4, A5, B6
    // we treat "our" as either A or B depending on firstPick
    const totalPicks = our + enemy;
    if (totalPicks >= 6) {
      return { label: "Draft complete", side: null };
    }

    const pattern = ["A", "B", "B", "A", "A", "B"];
    const turn = pattern[totalPicks];
    const ourSide = state.firstPick ? "A" : "B";
    const pickingIsUs = turn === ourSide;
    const pickIndex = totalPicks + 1;

    return {
      label: `Pick ${pickIndex} / 6`,
      side: pickingIsUs ? "Your pick" : "Enemy pick",
      pickingIsUs,
    };
  }, [state.phase, state.bans.length, state.ourPicks.length, state.enemyPicks.length, state.firstPick]);

  const filteredBrawlers = useMemo(() => {
    const q = state.search.trim().toLowerCase();
    return BRAWLERS.filter((b) => {
      if (takenSet.has(b.id)) return false;
      if (!q) return true;
      return (
        b.name.toLowerCase().includes(q) ||
        b.id.toLowerCase().includes(q)
      );
    });
  }, [state.search, takenSet]);

  const recommendations = useMemo(() => {
    if (state.phase !== "picks" || !currentMap) return [];
    try {
      return getRecommendations({
        mapId: currentMap.id,
        ourPicks: state.ourPicks,
        enemyPicks: state.enemyPicks,
        bans: state.bans,
        advanced,
      });
    } catch (e) {
      console.error("Recommendation error", e);
      return [];
    }
  }, [state.phase, currentMap, state.ourPicks, state.enemyPicks, state.bans, advanced]);

  function resetDraft() {
    setState(getInitialState());
  }

  function handleModeChange(mode) {
    const mapsForMode = MAPS_BY_MODE[mode] || [];
    setState((prev) => ({
      ...getInitialState(),
      mode,
      mapId: mapsForMode[0]?.id || null,
      firstPick: prev.firstPick,
    }));
  }

  function handleMapSelect(id) {
    setState((prev) => ({
      ...prev,
      mapId: id,
    }));
  }

  function handleFirstPickToggle(value) {
    setState((prev) => ({
      ...prev,
      firstPick: value,
    }));
  }

  function handleBrawlerClick(id) {
    if (takenSet.has(id)) return;
    setState((prev) => ({
      ...prev,
      pendingPick: id,
    }));
  }

  function confirmPending() {
    if (!state.pendingPick) return;
    const id = state.pendingPick;

    if (state.phase === "bans") {
      if (state.bans.length >= TOTAL_BANS) return;
      setState((prev) => {
        const bans = [...prev.bans, id];
        let phase = prev.phase;
        if (bans.length >= TOTAL_BANS) {
          phase = "picks";
        }
        return {
          ...prev,
          bans,
          pendingPick: null,
          phase,
        };
      });
      return;
    }

    // Picks
    setState((prev) => {
      const our = [...prev.ourPicks];
      const enemy = [...prev.enemyPicks];
      const totalPicks = our.length + enemy.length;
      if (totalPicks >= 6) {
        return { ...prev, pendingPick: null, phase: "done" };
      }

      const pattern = ["A", "B", "B", "A", "A", "B"];
      const turn = pattern[totalPicks];
      const ourSide = prev.firstPick ? "A" : "B";
      const pickingIsUs = turn === ourSide;

      if (pickingIsUs) {
        our.push(id);
      } else {
        enemy.push(id);
      }

      const newTotal = our.length + enemy.length;
      const phase = newTotal >= 6 ? "done" : "picks";

      return {
        ...prev,
        ourPicks: our,
        enemyPicks: enemy,
        pendingPick: null,
        phase,
      };
    });
  }

  function handleUseRecommendation(id) {
    if (takenSet.has(id)) return;
    setState((prev) => ({
      ...prev,
      pendingPick: id,
    }));
  }

  const bansRemaining = TOTAL_BANS - state.bans.length;

  return (
    <div className="page-grid">
      <section className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Draft setup</div>
            <div className="card-subtitle">
              Choose mode, map, side and run through bans and picks in live time.
            </div>
          </div>
          <button className="btn-ghost" onClick={resetDraft}>
            Reset draft
          </button>
        </div>

        <div className="section-title">Game mode</div>
        <div className="chips-row" style={{ marginBottom: 8 }}>
          {MODES.map((mode) => (
            <button
              key={mode}
              className="btn-ghost"
              style={{
                background:
                  state.mode === mode
                    ? "rgba(37,99,235,0.16)"
                    : "rgba(15,23,42,0.9)",
                borderColor:
                  state.mode === mode ? "#3b82f6" : "rgba(75,85,99,0.9)",
                color: state.mode === mode ? "#e5e7eb" : "#9ca3af",
              }}
              onClick={() => handleModeChange(mode)}
            >
              {mode}
            </button>
          ))}
        </div>

        <div className="section-title" style={{ marginTop: 10 }}>
          Map
        </div>
        <div className="section-caption">
          Tap a map to set it for this draft. Icons are from Worlds map pool.
        </div>
        <div className="map-grid">
          {(MAPS_BY_MODE[state.mode] || []).map((m) => (
            <button
              key={m.id}
              type="button"
              className={
                "map-tile" + (state.mapId === m.id ? " selected" : "")
              }
              onClick={() => handleMapSelect(m.id)}
            >
              {m.image && (
                <img src={m.image} alt={m.name} loading="lazy" />
              )}
              <div className="map-tile-footer">
                <div className="map-name">{m.name}</div>
                <div className="map-mode">{m.mode}</div>
              </div>
            </button>
          ))}
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: 12,
            gap: 10,
          }}
        >
          <div>
            <div className="section-title">Side</div>
            <div className="section-caption">
              Choose whether your team has first pick or last pick.
            </div>
          </div>
          <div className="chips-row">
            <button
              className="btn-ghost"
              style={{
                background: state.firstPick ? "rgba(59,130,246,0.18)" : "transparent",
                borderColor: state.firstPick ? "#3b82f6" : "rgba(75,85,99,0.9)",
                color: state.firstPick ? "#e5e7eb" : "#9ca3af",
              }}
              onClick={() => handleFirstPickToggle(true)}
            >
              First pick
            </button>
            <button
              className="btn-ghost"
              style={{
                background: !state.firstPick ? "rgba(56,189,248,0.18)" : "transparent",
                borderColor: !state.firstPick ? "#22d3ee" : "rgba(75,85,99,0.9)",
                color: !state.firstPick ? "#e5e7eb" : "#9ca3af",
              }}
              onClick={() => handleFirstPickToggle(false)}
            >
              Last pick
            </button>
          </div>
        </div>
      </section>

      <section className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Live draft</div>
            <div className="card-subtitle">
              First bans, then picks. Click a brawler and confirm to lock in.
            </div>
          </div>
          <div className="pill">
            {state.phase === "bans"
              ? `${bansRemaining} ban${bansRemaining === 1 ? "" : "s"} left`
              : state.phase === "picks"
              ? "Picking phase"
              : "Draft complete"}
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 8,
            gap: 10,
          }}
        >
          <div>
            <div className="section-title">
              {currentPickInfo.label}
            </div>
            <div className="section-caption">
              {currentPickInfo.side
                ? `${currentPickInfo.side}: choose a brawler below, then confirm.`
                : "You can still explore picks or reset to run a new draft."}
            </div>
          </div>
          <button
            className="btn-primary"
            disabled={!state.pendingPick}
            onClick={confirmPending}
          >
            Confirm
          </button>
        </div>

        <div
          className="draft-layout"
          style={{ marginBottom: 10 }}
        >
          <div className="draft-side">
            <div className="draft-side-header">
              <div>
                <div className="draft-side-title">Your side</div>
                <div className="draft-side-sub">
                  Bans & picks locked for your team
                </div>
              </div>
              <span className={state.firstPick ? "badge-first" : "badge-last"}>
                {state.firstPick ? "First pick" : "Last pick"}
              </span>
            </div>
            <div className="section-title">Bans</div>
            <div className="chips-row" style={{ marginBottom: 6 }}>
              {state.bans.map((id) => {
                const b = BRAWLERS.find((x) => x.id === id);
                return (
                  <div key={id} className="chip">
                    {b?.image && (
                      <img src={b.image} alt={b.name} />
                    )}
                    <span className="chip-label-strong">{b?.name || id}</span>
                    <span className="chip-meta">Ban</span>
                  </div>
                );
              })}
              {!state.bans.length && (
                <span className="chip-meta">No bans locked yet</span>
              )}
            </div>
            <div className="section-title">Your picks</div>
            <div className="chips-row">
              {state.ourPicks.map((id) => {
                const b = BRAWLERS.find((x) => x.id === id);
                return (
                  <div key={id} className="chip">
                    {b?.image && (
                      <img src={b.image} alt={b.name} />
                    )}
                    <span className="chip-label-strong">{b?.name || id}</span>
                    <span className="chip-meta">You</span>
                  </div>
                );
              })}
              {!state.ourPicks.length && (
                <span className="chip-meta">No picks yet</span>
              )}
            </div>
          </div>

          <div className="draft-side">
            <div className="draft-side-header">
              <div>
                <div className="draft-side-title">Enemy side</div>
                <div className="draft-side-sub">
                  Mirror their draft as you go.
                </div>
              </div>
            </div>
            <div className="section-title">Enemy picks</div>
            <div className="chips-row">
              {state.enemyPicks.map((id) => {
                const b = BRAWLERS.find((x) => x.id === id);
                return (
                  <div key={id} className="chip">
                    {b?.image && (
                      <img src={b.image} alt={b.name} />
                    )}
                    <span className="chip-label-strong">{b?.name || id}</span>
                    <span className="chip-meta">Enemy</span>
                  </div>
                );
              })}
              {!state.enemyPicks.length && (
                <span className="chip-meta">No enemy picks yet</span>
              )}
            </div>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 6,
            gap: 10,
          }}
        >
          <div>
            <div className="section-title">Brawler search</div>
            <div className="section-caption">
              Type to filter quickly. Click a brawler, then confirm.
            </div>
          </div>
          <input
            className="inline-input"
            placeholder="Search by name…"
            value={state.search}
            onChange={(e) =>
              setState((prev) => ({
                ...prev,
                search: e.target.value,
              }))
            }
            style={{ maxWidth: 220 }}
          />
        </div>

        <div className="brawler-grid">
          {filteredBrawlers.map((b) => {
            const isPending = state.pendingPick === b.id;
            const isRecommended = recommendations.some((r) => r.id === b.id);
            const must = recommendations.find((r) => r.id === b.id)?.mustPick;

            const classNames = [
              "brawler-tile",
              takenSet.has(b.id) ? "disabled" : "",
              isRecommended ? "recommended" : "",
              must ? "must" : "",
            ]
              .filter(Boolean)
              .join(" ");

            return (
              <button
                key={b.id}
                type="button"
                className={classNames}
                onClick={() => handleBrawlerClick(b.id)}
                disabled={takenSet.has(b.id)}
              >
                {b.image && (
                  <img src={b.image} alt={b.name} loading="lazy" />
                )}
                <div className="brawler-name">
                  {b.name}
                  {isPending && (
                    <span style={{ color: "#38bdf8", display: "block" }}>
                      Pending
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="card" style={{ gridColumn: "1 / -1", marginTop: 8 }}>
        <div className="card-header">
          <div>
            <div className="card-title">Recommended picks</div>
            <div className="card-subtitle">
              Suggestions based on Worlds data, map mode, bans, and comp shape.
            </div>
          </div>
        </div>

        {state.phase === "bans" && (
          <div className="section-caption">
            Lock all bans first. Recommendations will appear once picks start.
          </div>
        )}

        {state.phase !== "bans" && recommendations.length === 0 && (
          <div className="section-caption">
            No clear recommendation yet. Try adding picks or adjusting bans.
          </div>
        )}

        {state.phase !== "bans" && recommendations.length > 0 && (
          <div className="recommendations-list">
            {recommendations.map((r) => (
              <div
                key={r.id}
                className="rec-card"
                style={
                  r.mustPick
                    ? {
                        borderImage:
                          "linear-gradient(120deg,#f97316,#facc15,#22c55e,#38bdf8,#a855f7) 1",
                        borderWidth: 2,
                        borderStyle: "solid",
                      }
                    : undefined
                }
              >
                <div>
                  {r.image && (
                    <img
                      src={r.image}
                      alt={r.name}
                      style={{
                        width: 46,
                        height: 46,
                        borderRadius: 14,
                        objectFit: "cover",
                        display: "block",
                      }}
                    />
                  )}
                </div>
                <div className="rec-card-main">
                  <div className="rec-header-row">
                    <div>
                      <div className="rec-title">{r.name}</div>
                      <div className="rec-tags">
                        {r.tags.map((t) => (
                          <span key={t} className="pill">
                            {t}
                          </span>
                        ))}
                        {r.mustPick && (
                          <span className="rec-badge-must">MUST PICK</span>
                        )}
                      </div>
                    </div>
                    <button
                      className="btn-primary"
                      onClick={() => handleUseRecommendation(r.id)}
                    >
                      Use this pick
                    </button>
                  </div>
                  <div className="rec-explainer">
                    {advanced ? r.longExplanation : r.shortExplanation}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
