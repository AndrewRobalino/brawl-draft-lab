import React from "react";

const creators = [
  {
    id: "carter",
    display: "Carter "GOAT" B.",
    role: "Sharpshooter / Lane Specialist",
    avatar: "/assets/avatars/draco.jpg",
    favoriteBrawlers: ["piper", "belle", "mandy", "rico", "spike"],
    profileUrl: "https://brawlify.com/stats/profile/2LP2VJG",
  },
  {
    id: "andrew",
    display: "Andrew "Squadipoo" Robalino",
    role: "Mid / Tank Specialist",
    avatar: "/assets/avatars/frank.webp",
    favoriteBrawlers: ["gus", "meg", "frank", "doug", "bibi"],
    profileUrl: "https://brawlify.com/stats/profile/LL22UY8",
  },
];

export function AboutPage() {
  return (
    <div className="page-grid-single">
      <section className="card">
        <div className="card-header">
          <div>
            <div className="card-title">About Brawl Draft Lab</div>
            <div className="card-subtitle">
              A lightweight, Worlds-inspired draft helper for ranked &amp; scrims.
            </div>
          </div>
          <span className="pill pill-gold">Since Brawl Stars beta (2017)</span>
        </div>
        <p className="section-caption" style={{ marginBottom: 6 }}>
          Brawl Draft Lab was built by Carter and Andrew as a tool you can actually
          use during drafts. Instead of scrolling screenshots or guessing
          tier lists mid-game, you can quickly lock bans, mirror enemy picks,
          and see suggestions grounded in recent high-level data and basic role logic.
        </p>
        <p className="section-caption" style={{ marginBottom: 6 }}>
          Under the hood, the site blends Worlds-style draft data with soft
          heuristics around tanks, sharpshooters, throwers, control, and anti-tank
          options. That means you still get useful ideas even when the meta shifts
          or ladder looks different from esports drafts.
        </p>
        <p className="section-caption">
          Powered by Carter, Andrew, and a whole lot of notes — with a little help
          from an AI assistant.
        </p>
      </section>

      <section className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Creators</div>
            <div className="card-subtitle">
              Two long-time Brawl players who live in draft lobbies.
            </div>
          </div>
        </div>

        <div className="about-row">
          {creators.map((c, idx) => (
            <article key={c.id} className="about-profile">
              <img src={c.avatar} alt={c.display} className="about-avatar" />
              <div style={{ flex: 1 }}>
                <div className="about-name">{c.display}</div>
                <div className="about-role">{c.role}</div>
                <div className="about-tag-row">
                  {c.favoriteBrawlers.map((bId, i) => (
                    <span
                      key={bId}
                      className={
                        "about-brawler-chip" +
                        (idx === 0 && i === 0
                          ? " primary"
                          : idx === 1 && i === 0
                          ? " primary-gus"
                          : "")
                      }
                    >
                      {bId}
                    </span>
                  ))}
                </div>
                <a
                  href={c.profileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="about-link"
                >
                  View profile on Brawlify
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="card-header">
          <div>
            <div className="card-title">How to use this during drafts</div>
            <div className="card-subtitle">
              Meant to be fast, minimal, and mobile-friendly.
            </div>
          </div>
        </div>
        <ol
          style={{
            margin: 0,
            paddingLeft: 18,
            fontSize: "0.78rem",
            color: "#e5e7eb",
          }}
        >
          <li>Pick the mode and map you&apos;re playing.</li>
          <li>Set whether you have first pick or last pick.</li>
          <li>Lock in all six bans as they happen in the lobby.</li>
          <li>As you and the enemy pick, mirror both sides in the tool.</li>
          <li>
            Use the suggested brawlers as a fast guide — and toggle advanced
            explanations if you want to understand <em>why</em> they work.
          </li>
        </ol>
      </section>
    </div>
  );
}
