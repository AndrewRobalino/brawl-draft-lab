import { BRAWLERS } from "../data/brawlers";
import { MAPS } from "../data/maps";
import { META_BY_MAP } from "../data/metaByMap";

const BRAWLER_INDEX = Object.fromEntries(BRAWLERS.map((b) => [b.id, b]));

// Very lightweight role / tag mapping for explanation text
const ROLE_DATA = {
  // Tanks / frontliners
  frank: { roles: ["Tank"], tags: ["Huge HP", "Stun threat"] },
  bibi: { roles: ["Tank"], tags: ["Knockback", "Lane bully"] },
  meg: { roles: ["Tank", "Hybrid"], tags: ["Tank shredder", "Mech power spike"] },
  bull: { roles: ["Tank"], tags: ["Close range burst"] },
  ash: { roles: ["Tank"], tags: ["Snowball tank"], special: "anti_control" },
  sam: { roles: ["Tank"], tags: ["Scrapper"], special: "anti_tank" },
  doug: { roles: ["Support", "Tank"], tags: ["Revive heal"], special: "tank_enabler" },

  // Sharps / lanes
  piper: { roles: ["Sharpshooter"], tags: ["Long range", "Lane control"] },
  belle: { roles: ["Sharpshooter"], tags: ["Marking", "Versatile lane"] },
  mandy: { roles: ["Sharpshooter"], tags: ["Piercing snipe"] },
  rico: { roles: ["Sharpshooter"], tags: ["Bounce lanes"], special: "tight_lanes" },
  colt: { roles: ["Sharpshooter"], tags: ["High DPS"], special: "tank_melter" },
  brock: { roles: ["Sharpshooter"], tags: ["Area denial", "Lane control"] },

  // Supports / mids
  gus: { roles: ["Support", "Mid"], tags: ["Shields", "Anti-burst"], special: "anti_tank" },
  pam: { roles: ["Support", "Mid"], tags: ["Healing turret"], special: "sustain" },
  poco: { roles: ["Support"], tags: ["Team heal"], special: "tank_comp_enabler" },
  max: { roles: ["Support", "Hybrid"], tags: ["Speed", "Engage"], special: "tank_enabler" },

  // Anti-tank / niche
  spike: { roles: ["Damage"], tags: ["Tank shredder"], special: "anti_tank" },
  emz: { roles: ["Control"], tags: ["Anti-tank cone"], special: "anti_tank" },
  colette: { roles: ["Damage"], tags: ["Tank deletion"], special: "hard_anti_tank" },
  tara: { roles: ["Control"], tags: ["Pull"], special: "swing_pick" },
  cassidy: { roles: ["Damage"], tags: ["Burst"], special: "anti_tank" },
  clancy: { roles: ["Damage"], tags: ["High DPS"], special: "anti_tank" },

  // Throwers / control
  tick: { roles: ["Thrower"], tags: ["Area control"] },
  sprout: { roles: ["Thrower"], tags: ["Wall control"], special: "choke_control" },
  barley: { roles: ["Thrower"], tags: ["Area denial"] },

  // Misc meta picks
  cordelius: { roles: ["Assassin"], tags: ["Anti-healer"], special: "anti_tank" },
  lou: { roles: ["Control"], tags: ["Freeze lane"], special: "tank_counter" },
};

const TANKS = new Set(["frank", "bibi", "meg", "bull", "ash", "sam", "doug", "jacky", "rosa", "buzz", "el_primo"]);
const ANTI_TANK = new Set(
  Object.entries(ROLE_DATA)
    .filter(([, v]) => v.special && v.special.includes("anti_tank"))
    .map(([k]) => k)
);

function getMapKey(mapId) {
  const map = MAPS.find((m) => m.id === mapId);
  if (!map) return null;
  return map.name;
}

function scoreBrawler({ id, map, meta, ourPicks, enemyPicks, bans }) {
  const b = BRAWLER_INDEX[id];
  if (!b) return null;

  const mapMeta = meta || {};
  const baseMeta = mapMeta[id] || 0;

  let score = baseMeta * 1.6; // meta frequency has solid weight

  const roles = (ROLE_DATA[id]?.roles) || [];
  const special = ROLE_DATA[id]?.special || null;

  const mode = map?.mode || "";

  // Mode preferences
  if (mode === "Brawl Ball") {
    if (TANKS.has(id)) score += 3.5;
    if (roles.includes("Sharpshooter")) score += 2.0;
  } else if (mode === "Gem Grab") {
    if (roles.includes("Support") || roles.includes("Control") || roles.includes("Mid")) score += 2.4;
  } else if (mode === "Bounty") {
    if (roles.includes("Sharpshooter")) score += 3.2;
    if (roles.includes("Thrower")) score += 1.8;
  } else if (mode === "Hot Zone") {
    if (roles.includes("Control") || roles.includes("Thrower") || roles.includes("Tank")) score += 2.8;
  } else if (mode === "Heist") {
    if (roles.includes("Damage") || roles.includes("Tank")) score += 2.5;
  } else if (mode === "Knockout") {
    if (roles.includes("Sharpshooter") || roles.includes("Control")) score += 2.7;
  }

  // Count tanks on enemy side
  const enemyTankCount = enemyPicks.filter((p) => TANKS.has(p)).length;

  if (enemyTankCount >= 2) {
    if (ANTI_TANK.has(id)) score += 6.0;
    if (roles.includes("Support") && special === "tank_enabler") score -= 1.0; // don't enable enemy tanks
  } else if (enemyTankCount === 1) {
    if (ANTI_TANK.has(id)) score += 3.5;
  }

  // If we already have multiple tanks, down-weight more tanks unless mode wants it
  const ourTankCount = ourPicks.filter((p) => TANKS.has(p)).length;
  if (ourTankCount >= 2 && TANKS.has(id) && mode !== "Heist" && mode !== "Brawl Ball") {
    score -= 3.0;
  }

  // Synergy: enabling our tanks
  if (ourTankCount >= 1) {
    if (special === "tank_comp_enabler" || special === "tank_enabler") {
      score += 4.0;
    }
  }

  // Slight diversity penalty: don't recommend too many of the same archetype
  const ourRoles = new Set(
    ourPicks
      .map((p) => ROLE_DATA[p]?.roles || [])
      .flat()
  );
  if (roles.includes("Sharpshooter") && ourRoles.has("Sharpshooter") && mode === "Bounty") {
    score -= 1.0;
  }

  // Small general bump for known tournament staples
  if (["piper", "belle", "meg", "gus", "spike", "rico"].includes(id)) {
    score += 1.2;
  }

  return { id, score, roles, special };
}

function buildExplanation({ brawlerId, map, roles, special, meta, enemyPicks, advanced }) {
  const b = BRAWLER_INDEX[brawlerId];
  if (!b) return { short: "", long: "" };

  const mode = map?.mode || "";
  const name = b.name;
  const picksOnMap = meta?.[brawlerId] || 0;
  const enemyTankCount = enemyPicks.filter((p) => TANKS.has(p)).length;

  const roleText = roles.length ? roles.join(" / ") : "flex";
  const metaSnippet =
    picksOnMap > 0
      ? `${name} showed up ${picksOnMap} time${picksOnMap > 1 ? "s" : ""} on this map in recent drafts.`
      : `${name} didn't show up much in recent drafts here, but fits the comp.`;

  let antiTankSnippet = "";
  if (enemyTankCount >= 2 && ANTI_TANK.has(brawlerId)) {
    antiTankSnippet = ` It punishes tank-heavy comps really hard, especially once you position well.`;
  }

  const modeSnippet = (() => {
    if (!mode) return "";
    if (mode === "Brawl Ball") {
      return ` Great in Ball where spacing, lane control, and fast engages matter.`;
    }
    if (mode === "Gem Grab") {
      return ` Works well in Gem Grab where mid stability and lane control win games.`;
    }
    if (mode === "Bounty") {
      return ` Bounty favors safe range and survivability, which ${name} can provide when played correctly.`;
    }
    if (mode === "Hot Zone") {
      return ` Hot Zone rewards area control and holding space, which this pick helps with.`;
    }
    if (mode === "Heist") {
      return ` In Heist you get value from direct safe damage and aggressive pathing.`;
    }
    if (mode === "Knockout") {
      return ` Knockout is all about value trades and staying alive, which fits this pick.`;
    }
    return "";
  })();

  const specialSnippet = (() => {
    if (!special) return "";
    if (special === "anti_tank" || special === "hard_anti_tank") {
      return ` It acts as a direct answer to bulky tanks and short-range brawlers.`;
    }
    if (special === "tank_comp_enabler" || special === "tank_enabler") {
      return ` It pairs very well with your own tanks, letting them stay in the fight longer.`;
    }
    if (special === "sustain") {
      return ` Sustained healing and mid control keep your comp stable over long fights.`;
    }
    if (special === "choke_control") {
      return ` Wall and choke control can completely lock down narrow areas on this map.`;
    }
    return "";
  })();

  const short = `${name} acts as a ${roleText} pick on ${map?.name || "this map"}.`;
  const long =
    metaSnippet +
    antiTankSnippet +
    modeSnippet +
    (advanced ? " " + specialSnippet : "");

  return { short, long };
}

export function getRecommendations({ mapId, ourPicks, enemyPicks, bans, advanced }) {
  const map = MAPS.find((m) => m.id === mapId);
  if (!map) return [];

  const key = getMapKey(mapId);
  const meta = (META_BY_MAP && META_BY_MAP[key]) || {};

  const taken = new Set([...(ourPicks || []), ...(enemyPicks || []), ...(bans || [])]);

  const scored = [];
  for (const b of BRAWLERS) {
    if (taken.has(b.id)) continue;
    const s = scoreBrawler({
      id: b.id,
      map,
      meta,
      ourPicks: ourPicks || [],
      enemyPicks: enemyPicks || [],
      bans: bans || [],
    });
    if (!s) continue;
    scored.push(s);
  }

  if (!scored.length) return [];

  scored.sort((a, b) => b.score - a.score);

  const top = scored.slice(0, 3);
  const bestScore = top[0].score;
  const secondScore = top[1] ? top[1].score : bestScore - 1;

  return top.map((entry, idx) => {
    const b = BRAWLER_INDEX[entry.id];
    const expl = buildExplanation({
      brawlerId: entry.id,
      map,
      roles: entry.roles,
      special: entry.special,
      meta,
      enemyPicks: enemyPicks || [],
      advanced,
    });

    const tags = [];
    if ((META_BY_MAP[key]?.[entry.id] || 0) > 0) tags.push("Meta");
    if (entry.roles && entry.roles.length) tags.push(entry.roles.join(" / "));
    if (entry.special === "hard_anti_tank") tags.push("Shreds tanks");
    else if (entry.special === "anti_tank") tags.push("Anti-tank");
    if (idx === 0) tags.push("Safest pick");

    const mustPick =
      idx === 0 && bestScore > 0 && bestScore >= secondScore + 4;

    return {
      id: entry.id,
      name: b?.name || entry.id,
      image: b?.image,
      tags,
      shortExplanation: expl.short,
      longExplanation: expl.long,
      mustPick,
    };
  });
}
